package com.example.vms.service;

import com.example.vms.entity.University;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author vms
 * @since 2024-11-17
 */
public interface UniversityService extends IService<University> {

}
