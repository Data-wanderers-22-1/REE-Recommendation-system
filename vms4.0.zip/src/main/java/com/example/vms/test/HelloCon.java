


/*
@RestController
public class HelloCon {
    @GetMapping
    public String hello() {
        return "Hello vms";
    }
    @Autowired
    private UserService userService;

    @GetMapping("/list")
    public List<User> list() {return userService.list();}
}*/

